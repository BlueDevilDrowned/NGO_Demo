import bpy
from bpy.props import (
    BoolProperty,
    CollectionProperty,
    EnumProperty,
    IntProperty,
    PointerProperty,
    StringProperty,
)
from . import presets

class BBB_UL_TextureItem(bpy.types.PropertyGroup):
    mat_name: StringProperty(name="Material Name")
    node_name: StringProperty(name="Node Name")
    image_ptr: PointerProperty(type=bpy.types.Image, name="Texture")
    mark_type: StringProperty(name="Role")

class BBB_MainSettings(bpy.types.PropertyGroup):
    active_preset: EnumProperty(name="Shader Preset", items=presets.PRESET_ENUM, default="MMD")
    texture_list: CollectionProperty(type=BBB_UL_TextureItem)
    list_index: IntProperty(name="Index", default=0)
    texture_export_dir: StringProperty(
        name="Texture Folder",
        description="Folder used by Export Textures for Unity",
        default="//Textures",
        subtype='DIR_PATH',
    )
    overwrite_exported_textures: BoolProperty(
        name="Overwrite Existing",
        description="Replace files that already exist in the texture folder",
        default=False,
    )
    relink_exported_textures: BoolProperty(
        name="Relink Exported Copies",
        description=(
            "Point Blender images to the exported files so subsequent FBX "
            "exports can preserve their paths"
        ),
        default=True,
    )
