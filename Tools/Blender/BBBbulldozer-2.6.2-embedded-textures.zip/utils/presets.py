PRESET_ENUM = [
    ("MMD", "MMD Shader", "解析 MMDShaderDev"),
    ("XPS", "XPS/XNALara", "解析 XPS 提取节点"),
]

RULES = {
    "MMD": {
        "target_keywords": ["mmdshaderdev", "mmd"],
        "sockets": {
            "color": ["base tex", "diffuse", "base color"],
            "normal": ["normal map", "normal"],
            "alpha": ["alpha", "opacity"],
        },
    },
    "XPS": {
        "target_keywords": ["xps", "xnalara"],
        "sockets": {
            "color": ["diffuse", "base color"],
            "normal": ["normal", "bump"],
            "alpha": ["alpha", "opacity"],
        },
    },
}