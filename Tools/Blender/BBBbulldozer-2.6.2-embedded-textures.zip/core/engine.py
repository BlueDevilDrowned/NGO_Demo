import bpy
from ..utils import presets
from .scanner import get_upstream_tex_image, find_target_shader_node, find_socket_by_names

def get_all_upstream_nodes(start_node):
    """获取上游节点集合 (用于生成保护名单)"""
    upstream = set([start_node])
    queue = [start_node]
    while queue:
        curr = queue.pop(0)
        for inp in curr.inputs:
            if inp.is_linked:
                from_node = inp.links[0].from_node
                if from_node not in upstream:
                    upstream.add(from_node)
                    queue.append(from_node)
    return upstream

class BBB_OT_execute_bulldozer(bpy.types.Operator):
    bl_idname = "bbb.execute_bulldozer"
    bl_label = "2. Purge & Rebuild BSDF"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        settings = context.scene.bbb_settings
        preset_rules = presets.RULES.get(settings.active_preset)
        target_materials = {slot.material for obj in context.selected_objects if obj.type == 'MESH' for slot in obj.material_slots if slot.material and slot.material.use_nodes}

        success_count = 0
        for mat in target_materials:
            nodes = mat.node_tree.nodes
            links = mat.node_tree.links
            
            active_output = next((n for n in nodes if n.type == 'OUTPUT_MATERIAL' and n.is_active_output), None)
            
            # 状态检查：已是标准BSDF则跳过
            if active_output and active_output.inputs[0].is_linked and active_output.inputs[0].links[0].from_node.type == 'BSDF_PRINCIPLED':
                continue

            # 轨道一：降维提取 Fallback BSDF (VRM/glTF优先)
            existing_bsdf = next((n for n in nodes if n.type == 'BSDF_PRINCIPLED'), None)
            if existing_bsdf:
                safe_nodes = get_all_upstream_nodes(existing_bsdf)
                
                # 焚城：删除名单外节点
                for n in list(nodes):
                    if n not in safe_nodes: nodes.remove(n)
                        
                out_node = nodes.new('ShaderNodeOutputMaterial')
                out_node.location = (existing_bsdf.location[0] + 300, existing_bsdf.location[1])
                links.new(existing_bsdf.outputs[0], out_node.inputs[0])
                
                # Alpha 模式自动判定
                has_alpha = existing_bsdf.inputs.get('Alpha') and (existing_bsdf.inputs['Alpha'].is_linked or existing_bsdf.inputs['Alpha'].default_value < 1.0)
                if hasattr(mat, 'blend_method'): mat.blend_method = 'HASHED' if has_alpha else 'OPAQUE'
                if hasattr(mat, 'shadow_method'): mat.shadow_method = 'HASHED' if has_alpha else 'OPAQUE'
                
                success_count += 1
                continue

            # 轨道二：BFS 拓扑回溯重构 (MMD/XPS)
            target_node = find_target_shader_node(nodes, preset_rules["target_keywords"])
            if not target_node: continue
            
            img_color = get_upstream_tex_image(find_socket_by_names(target_node, preset_rules["sockets"]["color"]))
            img_normal = get_upstream_tex_image(find_socket_by_names(target_node, preset_rules["sockets"]["normal"]))
            img_alpha = get_upstream_tex_image(find_socket_by_names(target_node, preset_rules["sockets"]["alpha"]))
            if not img_alpha and img_color: img_alpha = img_color
            
            nodes.clear()
            out_node = nodes.new('ShaderNodeOutputMaterial')
            out_node.location = (300, 0)
            bsdf = nodes.new('ShaderNodeBsdfPrincipled')
            bsdf.location = (0, 0)
            links.new(bsdf.outputs[0], out_node.inputs[0])
            
            # 重建逻辑下的 Alpha 判定
            use_alpha = False
            if img_color:
                tex_c = nodes.new('ShaderNodeTexImage')
                tex_c.image = img_color
                tex_c.location = (-400, 200)
                links.new(tex_c.outputs['Color'], bsdf.inputs['Base Color'])
                if img_alpha == img_color and 'Alpha' in tex_c.outputs:
                    links.new(tex_c.outputs['Alpha'], bsdf.inputs['Alpha'])
                    use_alpha = True
            
            if hasattr(mat, 'blend_method'): mat.blend_method = 'HASHED' if use_alpha else 'OPAQUE'
            if hasattr(mat, 'shadow_method'): mat.shadow_method = 'HASHED' if use_alpha else 'OPAQUE'
            
            if img_normal:
                tex_n = nodes.new('ShaderNodeTexImage')
                tex_n.image = img_normal
                tex_n.location = (-400, -100)
                try: tex_n.image.colorspace_settings.name = 'Non-Color'
                except: pass
                nm = nodes.new('ShaderNodeNormalMap')
                nm.location = (-200, -100)
                links.new(tex_n.outputs['Color'], nm.inputs['Color'])
                links.new(nm.outputs['Normal'], bsdf.inputs['Normal'])
                
            success_count += 1
            
        settings.texture_list.clear()
        self.report({'INFO'}, f"执行完毕：重构 {success_count} 个材质")
        return {'FINISHED'}