import os
import re
import shutil
import tempfile

import bpy
from bpy.props import StringProperty
from bpy_extras.io_utils import ExportHelper


_INVALID_FILENAME_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def _selected_materials(context):
    return {
        slot.material
        for obj in context.selected_objects
        if obj.type == 'MESH'
        for slot in obj.material_slots
        if slot.material and slot.material.use_nodes
    }


def _collect_images_from_tree(node_tree, images, visited_trees):
    if not node_tree or node_tree.as_pointer() in visited_trees:
        return

    visited_trees.add(node_tree.as_pointer())
    for node in node_tree.nodes:
        if node.type == 'TEX_IMAGE' and node.image:
            images[node.image.as_pointer()] = node.image
        elif node.type == 'GROUP' and node.node_tree:
            _collect_images_from_tree(node.node_tree, images, visited_trees)


def _collect_images(materials):
    images = {}
    visited_trees = set()
    for material in materials:
        _collect_images_from_tree(material.node_tree, images, visited_trees)
    return list(images.values())


def _safe_filename(value):
    cleaned = _INVALID_FILENAME_CHARS.sub('_', value).strip().rstrip('.')
    return cleaned or 'texture'


def _source_path(image):
    filepath = image.filepath_raw or image.filepath
    return bpy.path.abspath(filepath) if filepath else ''


def _preferred_filename(image, source_path, force_png=False):
    candidate = os.path.basename(source_path) if source_path else image.name
    stem, extension = os.path.splitext(candidate)
    stem = _safe_filename(stem or image.name)
    if force_png or not extension:
        extension = '.png'
    return f"{stem}{extension.lower()}"


def _unique_destination(directory, filename, reserved_paths):
    stem, extension = os.path.splitext(filename)
    candidate = os.path.join(directory, filename)
    suffix = 2
    while os.path.normcase(candidate) in reserved_paths:
        candidate = os.path.join(directory, f"{stem}_{suffix}{extension}")
        suffix += 1
    reserved_paths.add(os.path.normcase(candidate))
    return candidate


def _write_packed_image(image, destination):
    packed_file = image.packed_file
    if packed_file is None:
        return False

    with open(destination, 'wb') as output:
        output.write(bytes(packed_file.data))
    return True


def _save_image_as_png(image, destination):
    old_filepath = image.filepath_raw
    old_format = image.file_format
    try:
        image.filepath_raw = destination
        image.file_format = 'PNG'
        image.save()
    finally:
        image.filepath_raw = old_filepath
        image.file_format = old_format


def _relink_image(image, destination):
    try:
        image.filepath = bpy.path.relpath(destination)
    except ValueError:
        image.filepath = destination


def _stage_images_for_fbx(images, directory):
    original_paths = []
    skipped = []
    reserved_paths = set()

    for image in images:
        if image.source in {'TILED', 'SEQUENCE', 'MOVIE'}:
            skipped.append(f'{image.name}（暂不支持 {image.source}）')
            continue

        source_path = _source_path(image)
        has_external_source = bool(source_path and os.path.isfile(source_path))
        has_packed_source = image.packed_file is not None
        force_png = not has_external_source and not has_packed_source
        filename = _preferred_filename(image, source_path, force_png)
        destination = _unique_destination(directory, filename, reserved_paths)

        try:
            if has_external_source:
                shutil.copy2(source_path, destination)
            elif has_packed_source:
                _write_packed_image(image, destination)
            elif image.has_data:
                _save_image_as_png(image, destination)
            else:
                skipped.append(f'{image.name}（没有可写入的图片数据）')
                continue

            original_paths.append((image, image.filepath_raw))
            image.filepath_raw = destination
        except (OSError, RuntimeError, ValueError) as error:
            skipped.append(f'{image.name}（{error}）')

    return original_paths, skipped


def _restore_image_paths(original_paths):
    for image, filepath_raw in original_paths:
        image.filepath_raw = filepath_raw


def _fbx_export_objects(context, selected_meshes):
    objects = {
        obj for obj in context.selected_objects
        if obj.type in {'EMPTY', 'MESH', 'ARMATURE'}
    }
    for mesh in selected_meshes:
        if mesh.parent and mesh.parent.type == 'ARMATURE':
            objects.add(mesh.parent)
        for modifier in mesh.modifiers:
            if modifier.type == 'ARMATURE' and modifier.object:
                objects.add(modifier.object)
    return objects


class BBB_OT_export_textures(bpy.types.Operator):
    bl_idname = 'bbb.export_textures'
    bl_label = '3. Export Textures for Unity'
    bl_description = (
        'Export every image used by the selected mesh materials and optionally '
        'relink the Blender images to the exported files'
    )

    def execute(self, context):
        settings = context.scene.bbb_settings
        materials = _selected_materials(context)
        if not materials:
            self.report({'ERROR'}, '请选择至少一个包含节点材质的 Mesh。')
            return {'CANCELLED'}

        if settings.texture_export_dir.startswith('//') and not bpy.data.filepath:
            self.report({'ERROR'}, '当前 .blend 尚未保存，无法解析相对输出目录。')
            return {'CANCELLED'}

        output_directory = bpy.path.abspath(settings.texture_export_dir)
        try:
            os.makedirs(output_directory, exist_ok=True)
        except OSError as error:
            self.report({'ERROR'}, f'无法创建贴图目录：{error}')
            return {'CANCELLED'}

        images = _collect_images(materials)
        if not images:
            self.report({'WARNING'}, '所选 Mesh 的材质中没有找到 Image Texture。')
            return {'CANCELLED'}

        exported = 0
        reused = 0
        skipped = []
        reserved_paths = set()

        for image in images:
            if image.source in {'TILED', 'SEQUENCE', 'MOVIE'}:
                skipped.append(f'{image.name}（暂不支持 {image.source}）')
                continue

            source_path = _source_path(image)
            has_external_source = bool(source_path and os.path.isfile(source_path))
            has_packed_source = image.packed_file is not None
            force_png = not has_external_source and not has_packed_source
            filename = _preferred_filename(image, source_path, force_png)
            destination = _unique_destination(
                output_directory, filename, reserved_paths)

            try:
                destination_exists = os.path.isfile(destination)
                same_file = False
                if has_external_source and destination_exists:
                    try:
                        same_file = os.path.samefile(source_path, destination)
                    except OSError:
                        same_file = False

                if destination_exists and not settings.overwrite_exported_textures:
                    reused += 1
                elif same_file:
                    reused += 1
                elif has_external_source:
                    shutil.copy2(source_path, destination)
                    exported += 1
                elif has_packed_source:
                    _write_packed_image(image, destination)
                    exported += 1
                elif image.has_data:
                    _save_image_as_png(image, destination)
                    exported += 1
                else:
                    skipped.append(f'{image.name}（没有可写入的图片数据）')
                    continue

                if settings.relink_exported_textures:
                    _relink_image(image, destination)
            except (OSError, RuntimeError, ValueError) as error:
                skipped.append(f'{image.name}（{error}）')

        if skipped:
            for message in skipped:
                self.report({'WARNING'}, f'跳过：{message}')

        self.report(
            {'INFO'},
            f'贴图导出完成：新增 {exported}，复用 {reused}，跳过 {len(skipped)}。'
        )
        return {'FINISHED'}


class BBB_OT_export_fbx_embedded(bpy.types.Operator, ExportHelper):
    bl_idname = 'bbb.export_fbx_embedded'
    bl_label = '4. Export FBX with Embedded Textures'
    bl_description = (
        'Export the selected meshes and their armatures to FBX, with supported '
        'material textures embedded for Unity Extract Textures'
    )

    filename_ext = '.fbx'
    filter_glob: StringProperty(default='*.fbx', options={'HIDDEN'})

    def execute(self, context):
        selected_meshes = [obj for obj in context.selected_objects if obj.type == 'MESH']
        if not selected_meshes:
            self.report({'ERROR'}, '请选择至少一个 Mesh。')
            return {'CANCELLED'}

        materials = {
            slot.material
            for obj in selected_meshes
            for slot in obj.material_slots
            if slot.material and slot.material.use_nodes
        }
        images = _collect_images(materials)
        if not images:
            self.report({'ERROR'}, '所选 Mesh 的材质中没有找到可内嵌的 Image Texture。')
            return {'CANCELLED'}

        filepath = bpy.path.ensure_ext(self.filepath, self.filename_ext)
        output_directory = os.path.dirname(filepath)
        try:
            os.makedirs(output_directory, exist_ok=True)
        except OSError as error:
            self.report({'ERROR'}, f'无法创建 FBX 输出目录：{error}')
            return {'CANCELLED'}

        export_objects = _fbx_export_objects(context, selected_meshes)
        original_selection = list(context.selected_objects)
        original_active = context.view_layer.objects.active
        original_mode = original_active.mode if original_active else 'OBJECT'
        original_paths = []
        skipped = []

        try:
            if context.object and context.object.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')

            with tempfile.TemporaryDirectory(prefix='bbb_fbx_textures_') as stage_directory:
                original_paths, skipped = _stage_images_for_fbx(images, stage_directory)
                if not original_paths:
                    self.report({'ERROR'}, '没有贴图成功写入 FBX 临时目录，已取消导出。')
                    return {'CANCELLED'}

                bpy.ops.object.select_all(action='DESELECT')
                for obj in export_objects:
                    obj.select_set(True)
                context.view_layer.objects.active = selected_meshes[0]

                result = bpy.ops.export_scene.fbx(
                    filepath=filepath,
                    use_selection=True,
                    object_types={'EMPTY', 'MESH', 'ARMATURE'},
                    apply_scale_options='FBX_SCALE_UNITS',
                    use_custom_props=True,
                    use_armature_deform_only=True,
                    add_leaf_bones=False,
                    bake_anim=False,
                    path_mode='COPY',
                    embed_textures=True,
                )
                if 'FINISHED' not in result:
                    raise RuntimeError('Blender FBX 导出器未完成导出。')
        except (OSError, RuntimeError, ValueError) as error:
            self.report({'ERROR'}, f'内嵌纹理 FBX 导出失败：{error}')
            return {'CANCELLED'}
        finally:
            _restore_image_paths(original_paths)
            bpy.ops.object.select_all(action='DESELECT')
            for obj in original_selection:
                if obj.name in context.view_layer.objects:
                    obj.select_set(True)
            if original_active and original_active.name in context.view_layer.objects:
                context.view_layer.objects.active = original_active
                if original_mode != 'OBJECT':
                    try:
                        bpy.ops.object.mode_set(mode=original_mode)
                    except RuntimeError:
                        self.report({'WARNING'}, f'无法恢复导出前模式：{original_mode}')

        for message in skipped:
            self.report({'WARNING'}, f'未内嵌：{message}')
        self.report(
            {'INFO'},
            f'FBX 已导出并请求内嵌 {len(original_paths)} 张贴图：{filepath}'
        )
        return {'FINISHED'}


def register():
    bpy.utils.register_class(BBB_OT_export_textures)
    bpy.utils.register_class(BBB_OT_export_fbx_embedded)


def unregister():
    bpy.utils.unregister_class(BBB_OT_export_fbx_embedded)
    bpy.utils.unregister_class(BBB_OT_export_textures)
