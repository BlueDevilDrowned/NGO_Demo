import bpy
from ..utils import presets

def get_upstream_tex_image(socket):
    if not socket or not socket.is_linked: return None
    queue = [socket.links[0].from_node]
    visited = set()
    while queue:
        curr = queue.pop(0)
        if curr in visited: continue
        visited.add(curr)
        if curr.type == 'TEX_IMAGE' and curr.image: return curr.image
        if curr.type == 'GROUP' and curr.node_tree:
            for inner_node in curr.node_tree.nodes:
                if inner_node.type == 'TEX_IMAGE' and inner_node.image:
                    return inner_node.image
        for inp in curr.inputs:
            if inp.is_linked: queue.append(inp.links[0].from_node)
    return None

def find_target_shader_node(nodes, keywords):
    for node in nodes:
        search_space = (node.name + " " + node.label).lower()
        if node.type == 'GROUP' and node.node_tree: search_space += " " + node.node_tree.name.lower()
        if any(kw in search_space for kw in keywords): return node
    return None

def find_socket_by_names(node, possible_names):
    if not node: return None
    for inp in node.inputs:
        if inp.name.lower() in [n.lower() for n in possible_names]: return inp
    return None

class BBB_OT_scan_textures(bpy.types.Operator):
    bl_idname = "bbb.scan_textures"
    bl_label = "1. Scan & Preview (Dry Run)"
    
    def execute(self, context):
        settings = context.scene.bbb_settings
        settings.texture_list.clear()
        preset_rules = presets.RULES.get(settings.active_preset)
        target_materials = {slot.material for obj in context.selected_objects if obj.type == 'MESH' for slot in obj.material_slots if slot.material and slot.material.use_nodes}
        
        count = 0
        for mat in target_materials:
            nodes = mat.node_tree.nodes
            
            # 轨道一：BSDF pick
            existing_bsdf = next((n for n in nodes if n.type == 'BSDF_PRINCIPLED'), None)
            if existing_bsdf:
                roles = {
                    "Color (Picked)": get_upstream_tex_image(existing_bsdf.inputs.get("Base Color")),
                    "Normal (Picked)": get_upstream_tex_image(existing_bsdf.inputs.get("Normal"))
                }
                node_name_to_show = existing_bsdf.name
            else:
                # 轨道二：BFS fallback
                target_node = find_target_shader_node(nodes, preset_rules["target_keywords"])
                if not target_node: continue
                roles = {
                    "Color": get_upstream_tex_image(find_socket_by_names(target_node, preset_rules["sockets"]["color"])),
                    "Normal": get_upstream_tex_image(find_socket_by_names(target_node, preset_rules["sockets"]["normal"])),
                    "Alpha": get_upstream_tex_image(find_socket_by_names(target_node, preset_rules["sockets"]["alpha"]))
                }
                node_name_to_show = target_node.name

            for role_name, img in roles.items():
                if img:
                    item = settings.texture_list.add()
                    item.mat_name = mat.name
                    item.node_name = node_name_to_show
                    item.image_ptr = img
                    item.mark_type = role_name
                    count += 1
                    
        self.report({'INFO'}, f"扫描完毕：锁定 {count} 张有效核心贴图。")
        return {'FINISHED'}

def register(): bpy.utils.register_class(BBB_OT_scan_textures)
def unregister(): bpy.utils.unregister_class(BBB_OT_scan_textures)