# BBBbulldozer (推土机) V2.6.2

![Blender 4.0+](https://img.shields.io/badge/Blender-4.0%2B-orange)
![License](https://img.shields.io/badge/License-GPL--2.0--or--later-blue)
![Version](https://img.shields.io/badge/Version-2.6.2-green)

一款面向工业级 3D 游戏资产导入管线的极简材质清洗工具。专治二次元、解包模型，以及各种无序渲染节点（NPR Shader）。目标是把复杂材质稳定收敛为游戏引擎可识别的标准 PBR 结构。

## 核心特性：双轨制重构引擎

本工具不再依赖脆弱的字符串猜测，而是基于节点图拓扑解析：

- **Track 1: 降维提取（Fallback BSDF）**
  当节点树中已经存在 `ShaderNodeBsdfPrincipled` 时，直接回溯其上游节点形成保护名单，清除其余冗余节点，并将结果接回标准输出。
- **Track 2: BFS 拓扑回溯**
  当材质没有现成 BSDF 时，使用广度优先搜索（BFS）从目标 Shader 节点提取 Color / Normal / Alpha 贴图，并重建标准 Principled BSDF 链路。
- **Alpha 渲染防呆机制**
  只有在确实使用透明通道时才启用 `HASHED`；否则强制回落为 `OPAQUE`，避免游戏引擎中的深度排序问题。

## 工作流

1. 选择包含材质的网格物体。
2. 在侧边栏选择预设（MMD / VRM MToon / XPS）。
3. 点击 **Scan & Preview** 查看扫描结果。
4. 确认后点击 **Execute Rebuild** 执行重建。
5. 设置 **Texture Folder**，点击 **Export Textures for Unity** 导出所选网格材质引用的图片。
6. 点击 **Export FBX with Embedded Textures**，选择 FBX 路径，直接生成可供 Unity 提取纹理的 FBX。

## Unity 贴图导出

- 默认导出目录为当前 `.blend` 文件同级的 `Textures` 文件夹。
- 外部图片保持原格式复制，Packed 图片保持原始字节导出，Generated 图片导出为 PNG。
- 默认将 Blender 图片路径重定向到导出的文件，方便后续 FBX 导出保留贴图引用。
- 支持递归扫描嵌套 Node Group，并按图片数据块去重。
- 当前不支持 UDIM、图片序列和视频纹理；这些项目会被跳过并在状态栏报告。
- 内嵌导出会自动包含所选 Mesh 及其 Armature 修改器或父级引用的骨架，默认不烘焙动画。
- 导出期间使用临时贴图文件，完成后恢复 Blender 中原有图片路径，不会额外留下贴图目录。

## 预设

- `MMD`：`MMDShaderDev` / MMD 系材质
- `MTOON`：VRM MToon 节点组
- `XPS`：XPS / XNALara 节点结构

## 安装

1. 下载最新 ZIP 包。
2. 在 Blender 中打开 `编辑 -> 偏好设置 -> 扩展 -> 从磁盘安装`。
3. 选择 ZIP 文件并启用 `BBBbulldozer`。

## 文件结构

```text
BBBbulldozer/
├── __init__.py
├── blender_manifest.toml
├── core/
│   ├── scanner.py
│   ├── engine.py
│   └── exporter.py
├── ui/
│   ├── uilist.py
│   └── panel.py
└── utils/
    ├── presets.py
    └── properties.py
```

## 版本说明

### v2.6.2
- 新增一键导出内嵌纹理 FBX，面向 Unity 的 `Extract Textures` 工作流。
- 自动包含所选网格关联的骨架，且不会自动执行材质清理或动画烘焙。
- 支持将外部、Packed 和 Generated 图片临时落盘后写入 FBX。

### v2.6.1
- 新增面向 Unity 的一键贴图导出。
- 支持外部、Packed 和 Generated 图片。
- 新增输出目录、覆盖已有文件和重定向导出副本选项。

### v2.6.0
- 引入双轨制重构引擎
- 支持现成 BSDF 的快速摘取路径
- 支持 BFS 拓扑回溯与 VRM Group 穿透
- 增加 Alpha OPAQUE/HASHED 防呆

## 许可

GPL-2.0-or-later
