import bpy
class BBB_UL_texture_list(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        split = layout.split(factor=0.4)
        img_name = item.image_ptr.name if item.image_ptr else "无贴图"
        split.label(text=img_name, icon='IMAGE_DATA')
        sub = split.split(factor=0.5)
        sub.label(text=item.mark_type, icon='INFO')
        sub.label(text=f"[{item.mat_name}]")

def register(): bpy.utils.register_class(BBB_UL_texture_list)
def unregister(): bpy.utils.unregister_class(BBB_UL_texture_list)