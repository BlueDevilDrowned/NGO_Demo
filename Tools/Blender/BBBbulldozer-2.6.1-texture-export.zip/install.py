#!/usr/bin/env python3
"""
BBBbulldozer Installation Helper
This script helps install the addon to Blender's addons directory.
"""

import os
import sys
import shutil
import platform
from pathlib import Path

def get_blender_addons_path():
    """Get the Blender addons directory based on OS."""
    system = platform.system()
    username = os.getenv('USERNAME') or os.getenv('USER')
    
    if system == 'Windows':
        # Try to find Blender version
        blender_versions = []
        appdata = os.getenv('APPDATA')
        blender_dir = Path(appdata) / 'Blender Foundation' / 'Blender'
        
        if blender_dir.exists():
            for version_dir in blender_dir.iterdir():
                if version_dir.is_dir() and version_dir.name.replace('.', '').isdigit():
                    blender_versions.append(version_dir)
        
        if blender_versions:
            # Use the latest version
            latest = max(blender_versions, key=lambda x: float(x.name))
            return latest / 'scripts' / 'addons'
        else:
            # Fallback to typical path
            return Path(appdata) / 'Blender Foundation' / 'Blender' / '4.5' / 'scripts' / 'addons'
    
    elif system == 'Darwin':  # macOS
        home = Path.home()
        return home / 'Library' / 'Application Support' / 'Blender' / '4.5' / 'scripts' / 'addons'
    
    else:  # Linux
        home = Path.home()
        return home / '.config' / 'blender' / '4.5' / 'scripts' / 'addons'

def install_addon(source_dir, target_dir=None):
    """Install the addon to Blender's addons directory."""
    if target_dir is None:
        target_dir = get_blender_addons_path()
    
    source_dir = Path(source_dir).resolve()
    addon_name = source_dir.name
    target_path = Path(target_dir) / addon_name
    
    print("=" * 60)
    print("BBBbulldozer Blender Addon Installer")
    print("=" * 60)
    print(f"Source:      {source_dir}")
    print(f"Destination: {target_path}")
    print(f"Addon name:  {addon_name}")
    print()
    
    # Check if source exists
    if not source_dir.exists():
        print(f"❌ Error: Source directory not found: {source_dir}")
        return False
    
    # Check if __init__.py exists
    init_file = source_dir / '__init__.py'
    if not init_file.exists():
        print(f"❌ Error: Not a valid Blender addon (missing __init__.py)")
        return False
    
    # Create target directory if it doesn't exist
    target_dir.parent.mkdir(parents=True, exist_ok=True)
    
    # Remove existing installation if it exists
    if target_path.exists():
        print(f"⚠️  Removing existing installation...")
        try:
            shutil.rmtree(target_path)
            print(f"✅ Removed old installation")
        except Exception as e:
            print(f"❌ Failed to remove old installation: {e}")
            return False
    
    # Copy addon
    try:
        print(f"📦 Copying addon files...")
        shutil.copytree(source_dir, target_path)
        print(f"✅ Addon copied successfully")
    except Exception as e:
        print(f"❌ Failed to copy addon: {e}")
        return False
    
    # Verify installation
    verify_file = target_path / '__init__.py'
    if verify_file.exists():
        print(f"✅ Installation verified")
    else:
        print(f"❌ Installation verification failed")
        return False
    
    print()
    print("=" * 60)
    print("🎉 Installation Complete!")
    print("=" * 60)
    print()
    print("Next steps:")
    print("1. Open Blender")
    print("2. Go to Edit → Preferences → Add-ons")
    print("3. Search for 'BBBbulldozer'")
    print("4. Enable the addon")
    print("5. Find it in the 3D Viewport sidebar (press N)")
    print()
    print("For help, see README.md")
    print("=" * 60)
    
    return True

def create_zip_package(source_dir, output_zip=None):
    """Create a ZIP package for manual installation."""
    import zipfile
    
    source_dir = Path(source_dir).resolve()
    if output_zip is None:
        output_zip = source_dir.parent / f"{source_dir.name}.zip"
    
    print(f"📦 Creating ZIP package: {output_zip}")
    
    try:
        with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
            for root, dirs, files in os.walk(source_dir):
                # Skip __pycache__ directories
                dirs[:] = [d for d in dirs if d != '__pycache__']
                
                for file in files:
                    if file.endswith('.pyc'):
                        continue  # Skip compiled Python files
                    
                    file_path = Path(root) / file
                    arcname = file_path.relative_to(source_dir.parent)
                    zipf.write(file_path, arcname)
        
        size_mb = os.path.getsize(output_zip) / (1024 * 1024)
        print(f"✅ ZIP package created: {output_zip} ({size_mb:.2f} MB)")
        return output_zip
        
    except Exception as e:
        print(f"❌ Failed to create ZIP: {e}")
        return None

def main():
    """Main installation routine."""
    # Get the directory where this script is located
    script_dir = Path(__file__).parent
    addon_dir = script_dir
    
    print("BBBbulldozer Installation Options:")
    print("1. Install directly to Blender addons directory")
    print("2. Create ZIP package for manual installation")
    print("3. Both (install and create ZIP)")
    print("4. Exit")
    
    try:
        choice = input("\nSelect option (1-4): ").strip()
        
        if choice == '1':
            install_addon(addon_dir)
        elif choice == '2':
            zip_file = create_zip_package(addon_dir)
            if zip_file:
                print(f"\n✅ ZIP package ready: {zip_file}")
                print("You can now install this ZIP file in Blender:")
                print("Edit → Preferences → Add-ons → Install...")
        elif choice == '3':
            if install_addon(addon_dir):
                create_zip_package(addon_dir)
        elif choice == '4':
            print("Exiting...")
        else:
            print("Invalid choice")
            
    except KeyboardInterrupt:
        print("\nInstallation cancelled.")
    except Exception as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()