﻿import bpy
from .utils import properties
from .core import scanner, engine, exporter
from .ui import uilist, panel

# 集中管理注册类
classes = (
    properties.BBB_UL_TextureItem,
    properties.BBB_MainSettings,
    scanner.BBB_OT_scan_textures,
    engine.BBB_OT_execute_bulldozer,
    exporter.BBB_OT_export_textures,
    uilist.BBB_UL_texture_list,
    panel.BBB_PT_main_panel,
)

def register():
    for cls in classes:
        try:
            bpy.utils.unregister_class(cls)
        except:
            pass
    try:
        for cls in classes:
            bpy.utils.register_class(cls)

        if hasattr(bpy.types.Scene, 'bbb_settings'):
            del bpy.types.Scene.bbb_settings
        bpy.types.Scene.bbb_settings = bpy.props.PointerProperty(type=properties.BBB_MainSettings)
    except:
        unregister()
        raise

def unregister():
    if hasattr(bpy.types.Scene, 'bbb_settings'):
        del bpy.types.Scene.bbb_settings

    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except:
            pass
