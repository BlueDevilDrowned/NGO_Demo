"""Thumbnail cache helpers."""

import bpy
import os
import time
import threading
from gpu import texture

_texture_cache = {}
_cache_lock = threading.Lock()
_placeholder_texture = None

def get_placeholder_texture():
    """Return a placeholder texture for missing images."""
    global _placeholder_texture
    
    if _placeholder_texture is None:
        import numpy as np
        size = 64
        pixels = np.full((size, size, 4), 0.5, dtype=np.float32)
        _placeholder_texture = texture.from_buffer(pixels.tobytes(), (size, size), 4, 'FLOAT')
    
    return _placeholder_texture

def get_texture(image_path, force_reload=False):
    """Return GPU texture data as (texture, width, height)."""
    if not image_path or not os.path.exists(image_path):
        return None, 0, 0
    
    try:
        mtime = os.path.getmtime(image_path)
        
        with _cache_lock:
            cache_entry = _texture_cache.get(image_path)
            
            if cache_entry and not force_reload:
                if cache_entry["mtime"] == mtime:
                    return cache_entry["tex"], cache_entry["w"], cache_entry["h"]
            
            try:
                img = bpy.data.images.load(image_path, check_existing=True)
                
                if img.size[0] == 0 or img.size[1] == 0:
                    img = None
                    tex = get_placeholder_texture()
                    width, height = 64, 64
                else:
                    tex = texture.from_image(img)
                    width, height = img.size
                
                _texture_cache[image_path] = {
                    "mtime": mtime,
                    "tex": tex,
                    "w": width,
                    "h": height,
                    "image": img
                }
                
                return tex, width, height
                
            except Exception as e:
                print(f"加载图片失败 {image_path}: {e}")
                return None, 0, 0
                
    except Exception as e:
        print(f"获取纹理失败 {image_path}: {e}")
        return None, 0, 0

def clear_cache():
    """Clear the cache."""
    global _texture_cache
    
    with _cache_lock:
        for entry in _texture_cache.values():
            if "image" in entry and entry["image"]:
                pass
        
        _texture_cache.clear()

def remove_from_cache(image_path):
    """Remove a single path from the cache."""
    with _cache_lock:
        if image_path in _texture_cache:
            entry = _texture_cache[image_path]
            if "image" in entry and entry["image"]:
                pass
            del _texture_cache[image_path]

def get_cache_info():
    """Return cache metadata."""
    with _cache_lock:
        return {
            "count": len(_texture_cache),
            "paths": list(_texture_cache.keys())
        }