#!/usr/bin/env python3
"""
BBBbulldozer Packaging Script
Creates a distributable ZIP package for Blender addon installation.
"""

import os
import sys
import zipfile
import shutil
from pathlib import Path
import json

def create_manifest():
    """Create a manifest file for the addon."""
    manifest = {
        "name": "BBBbulldozer",
        "version": "2.5.0",
        "blender_version": "4.5.0",
        "author": "Silencgai",
        "description": "Interactive PBR extractor with UIList and Presets",
        "category": "Material",
        "files": [
            "__init__.py",
            "README.md",
            "LICENSE",
            "install.py",
            "core/__init__.py",
            "core/scanner.py",
            "core/engine.py",
            "ui/__init__.py",
            "ui/uilist.py",
            "ui/panel.py",
            "utils/__init__.py",
            "utils/presets.py",
            "utils/properties.py"
        ]
    }
    
    return manifest

def clean_directory(directory):
    """Remove unnecessary files before packaging."""
    print(f"🧹 Cleaning directory: {directory}")
    
    # Files and directories to remove
    patterns_to_remove = [
        "__pycache__",
        "*.pyc",
        "*.pyo",
        "*.pyd",
        ".DS_Store",
        "Thumbs.db",
        "desktop.ini",
        "*.log",
        "*.tmp",
        "*.bak"
    ]
    
    removed_count = 0
    for pattern in patterns_to_remove:
        for file_path in directory.rglob(pattern):
            try:
                if file_path.is_file():
                    file_path.unlink()
                    removed_count += 1
                elif file_path.is_dir():
                    shutil.rmtree(file_path)
                    removed_count += 1
            except Exception as e:
                print(f"  ⚠️  Could not remove {file_path}: {e}")
    
    print(f"  ✅ Removed {removed_count} unnecessary files/directories")
    return removed_count

def validate_addon(directory):
    """Validate that the addon has all required files."""
    print(f"🔍 Validating addon structure...")
    
    required_files = [
        directory / "__init__.py",
        directory / "core" / "__init__.py",
        directory / "core" / "scanner.py",
        directory / "core" / "engine.py",
        directory / "ui" / "__init__.py",
        directory / "ui" / "uilist.py",
        directory / "ui" / "panel.py",
        directory / "utils" / "__init__.py",
        directory / "utils" / "presets.py",
        directory / "utils" / "properties.py",
    ]
    
    missing_files = []
    for file_path in required_files:
        if not file_path.exists():
            missing_files.append(str(file_path.relative_to(directory)))
    
    if missing_files:
        print(f"❌ Missing required files:")
        for missing in missing_files:
            print(f"   - {missing}")
        return False
    
    # Check __init__.py has bl_info
    init_file = directory / "__init__.py"
    with open(init_file, 'r', encoding='utf-8') as f:
        content = f.read()
        if 'bl_info' not in content:
            print("❌ __init__.py missing bl_info dictionary")
            return False
    
    print(f"✅ Addon structure is valid")
    return True

def calculate_size(directory):
    """Calculate total size of addon files."""
    total_size = 0
    file_count = 0
    
    for root, dirs, files in os.walk(directory):
        # Skip __pycache__
        dirs[:] = [d for d in dirs if d != '__pycache__']
        
        for file in files:
            if file.endswith('.pyc'):
                continue
            
            file_path = Path(root) / file
            total_size += file_path.stat().st_size
            file_count += 1
    
    return total_size, file_count

def create_zip_package(source_dir, output_zip=None):
    """Create a ZIP package for Blender addon installation."""
    source_dir = Path(source_dir).resolve()
    addon_name = source_dir.name
    
    if output_zip is None:
        output_zip = source_dir.parent / f"{addon_name}_v2.5.0.zip"
    
    print("=" * 60)
    print("BBBbulldozer Packaging Tool")
    print("=" * 60)
    print(f"Addon:      {addon_name}")
    print(f"Version:    2.5.0")
    print(f"Source:     {source_dir}")
    print(f"Output:     {output_zip}")
    print()
    
    # Step 1: Clean directory
    clean_directory(source_dir)
    
    # Step 2: Validate addon
    if not validate_addon(source_dir):
        print("❌ Addon validation failed. Packaging aborted.")
        return None
    
    # Step 3: Calculate size
    total_size, file_count = calculate_size(source_dir)
    print(f"📊 Package stats: {file_count} files, {total_size/1024:.1f} KB")
    
    # Step 4: Create manifest
    manifest = create_manifest()
    manifest_file = source_dir / "manifest.json"
    with open(manifest_file, 'w', encoding='utf-8') as f:
        json.dump(manifest, f, indent=2)
    
    # Step 5: Create ZIP
    print(f"📦 Creating ZIP package...")
    
    try:
        with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
            # Add all files
            for root, dirs, files in os.walk(source_dir):
                # Skip __pycache__ and the manifest file we just created
                dirs[:] = [d for d in dirs if d != '__pycache__']
                
                for file in files:
                    if file == 'manifest.json':
                        continue  # Don't include manifest in ZIP
                    
                    file_path = Path(root) / file
                    
                    # Skip compiled files
                    if file.endswith('.pyc'):
                        continue
                    
                    # Calculate relative path for ZIP
                    arcname = file_path.relative_to(source_dir.parent)
                    zipf.write(file_path, arcname)
            
            # Add a simple install guide text file
            install_guide = """BBBbulldozer Installation Guide
====================================

1. In Blender, go to Edit → Preferences → Add-ons
2. Click "Install..." button
3. Select this ZIP file
4. Search for "BBBbulldozer" in the addons list
5. Enable the addon
6. Find it in the 3D Viewport sidebar (press N)

For more details, see README.md inside the addon folder.

Happy bulldozing! 🚜
"""
            zipf.writestr("INSTALL.txt", install_guide)
        
        # Remove manifest file
        manifest_file.unlink()
        
        # Get final size
        zip_size = output_zip.stat().st_size
        zip_size_mb = zip_size / (1024 * 1024)
        
        print(f"✅ ZIP package created successfully!")
        print(f"   Size: {zip_size_mb:.2f} MB")
        print(f"   Files: {file_count}")
        print()
        print("📦 Package Contents:")
        
        # List contents
        with zipfile.ZipFile(output_zip, 'r') as zipf:
            for name in sorted(zipf.namelist()):
                if not name.endswith('/'):  # Skip directories
                    info = zipf.getinfo(name)
                    size_kb = info.file_size / 1024
                    print(f"   {name} ({size_kb:.1f} KB)")
        
        print()
        print("🎉 Ready for distribution!")
        print(f"   File: {output_zip}")
        print()
        print("Installation methods:")
        print("1. Use the ZIP file in Blender (Edit → Preferences → Add-ons → Install...)")
        print("2. Run: python install.py")
        print("3. Manually copy to Blender addons directory")
        print("=" * 60)
        
        return output_zip
        
    except Exception as e:
        print(f"❌ Failed to create ZIP: {e}")
        return None

def main():
    """Main packaging routine."""
    # Get the directory where this script is located
    script_dir = Path(__file__).parent
    addon_dir = script_dir
    
    print("BBBbulldozer Packaging")
    print("=" * 40)
    
    # Create ZIP package
    zip_file = create_zip_package(addon_dir)
    
    if zip_file:
        print(f"\n✅ Package created: {zip_file}")
        
        # Offer to copy to a common location
        try:
            choice = input("\nCopy to Desktop for easy access? (y/n): ").strip().lower()
            if choice == 'y':
                desktop = Path.home() / 'Desktop'
                dest = desktop / zip_file.name
                shutil.copy2(zip_file, dest)
                print(f"✅ Copied to: {dest}")
        except:
            pass  # Ignore errors in copy operation
    
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()