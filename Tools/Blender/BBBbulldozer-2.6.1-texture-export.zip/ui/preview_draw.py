"""Preview drawing helpers."""

import bpy
import gpu
from gpu_extras.batch import batch_for_shader
from ..utils import thumbs

_preview_handler = None

_shader = None

def _get_shader():
    """Get or create the preview shader."""
    global _shader
    if _shader is None:
        _shader = gpu.shader.from_builtin('IMAGE')
    return _shader

def _draw_preview_callback():
    """Draw the preview overlay."""
    context = bpy.context
    settings = getattr(context.scene, 'bbb_settings', None)
    
    if not settings or not settings.preview_enabled:
        return
    
    if len(settings.texture_list) == 0 or settings.list_index < 0:
        return
    
    active_idx = settings.list_index
    if active_idx >= len(settings.texture_list):
        return
    
    active_item = settings.texture_list[active_idx]
    if not active_item.preview_available or not active_item.image_path:
        return
    
    tex, width, height = thumbs.get_texture(active_item.image_path)
    if not tex:
        return
    
    region = context.region
    if not region:
        return
    
    panel_width = 300
    margin = 10
    preview_size = settings.preview_size
    
    x = region.width - panel_width + margin
    y = region.height - preview_size - margin
    
    if x < 0:
        x = margin
    if y < 0:
        y = margin
    
    vertices = (
        (x, y),
        (x + preview_size, y),
        (x + preview_size, y + preview_size),
        (x, y + preview_size)
    )
    
    tex_coords = (
        (0, 0),
        (1, 0),
        (1, 1),
        (0, 1)
    )
    
    indices = ((0, 1, 2), (0, 2, 3))
    
    shader = _get_shader()
    
    shader.bind()
    shader.uniform_sampler("image", tex)
    
    batch = batch_for_shader(
        shader, 'TRIS',
        {"pos": vertices, "texCoord": tex_coords},
        indices=indices
    )
    
    batch.draw(shader)
    
    gpu.state.line_width_set(1.0)
    border_color = (0.8, 0.8, 0.8, 1.0)
    
    border_vertices = (
        (x, y),
        (x + preview_size, y),
        (x + preview_size, y + preview_size),
        (x, y + preview_size)
    )
    
    border_indices = ((0, 1), (1, 2), (2, 3), (3, 0))
    
    border_shader = gpu.shader.from_builtin('UNIFORM_COLOR')
    border_batch = batch_for_shader(
        border_shader, 'LINES',
        {"pos": border_vertices},
        indices=border_indices
    )
    
    border_shader.bind()
    border_shader.uniform_float("color", border_color)
    border_batch.draw(border_shader)

def enable_preview():
    """Enable preview drawing."""
    global _preview_handler
    
    if _preview_handler is not None:
        return
    
    _preview_handler = bpy.types.SpaceView3D.draw_handler_add(
        _draw_preview_callback,
        (),
        'WINDOW',
        'POST_PIXEL'
    )
    
    print("BBBbulldozer: 预览绘制已启用")

def disable_preview():
    """Disable preview drawing."""
    global _preview_handler
    
    if _preview_handler is not None:
        bpy.types.SpaceView3D.draw_handler_remove(_preview_handler, 'WINDOW')
        _preview_handler = None
        
        print("BBBbulldozer: 预览绘制已禁用")

def is_preview_enabled():
    """Return whether preview drawing is enabled."""
    return _preview_handler is not None

def toggle_preview(context):
    """Toggle preview state."""
    settings = context.scene.bbb_settings
    
    if settings.preview_enabled:
        enable_preview()
    else:
        disable_preview()

def update_preview_settings(context):
    """Sync preview state with settings."""
    settings = context.scene.bbb_settings
    
    if settings.preview_enabled and not is_preview_enabled():
        enable_preview()
    elif not settings.preview_enabled and is_preview_enabled():
        disable_preview()