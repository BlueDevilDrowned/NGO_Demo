import bpy
class BBB_PT_main_panel(bpy.types.Panel):
    bl_label = "BBBbulldozer (Pro Pipeline)"
    bl_idname = "BBB_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = 'BBBbulldozer'

    def draw(self, context):
        layout = self.layout
        settings = context.scene.bbb_settings
        
        layout.prop(settings, "active_preset")
        layout.operator("bbb.scan_textures", icon='VIEWZOOM')
        layout.operator("bbb.execute_bulldozer", icon='PLAY')

        layout.separator()
        layout.label(text="Unity Texture Export", icon='TEXTURE')
        layout.prop(settings, "texture_export_dir")
        row = layout.row(align=True)
        row.prop(settings, "overwrite_exported_textures")
        row.prop(settings, "relink_exported_textures")
        layout.operator("bbb.export_textures", icon='EXPORT')
        
        if len(settings.texture_list) > 0:
            layout.separator()
            layout.label(text="Validation Preview (Read-Only):", icon='LOCKED')
            layout.template_list("BBB_UL_texture_list", "", settings, "texture_list", settings, "list_index", rows=5)
            
            active_idx = settings.list_index
            if 0 <= active_idx < len(settings.texture_list):
                active_item = settings.texture_list[active_idx]
                box = layout.box()
                if active_item.image_ptr:
                    box.template_ID_preview(active_item, "image_ptr", open="image.open", rows=4)

def register(): bpy.utils.register_class(BBB_PT_main_panel)
def unregister(): bpy.utils.unregister_class(BBB_PT_main_panel)
