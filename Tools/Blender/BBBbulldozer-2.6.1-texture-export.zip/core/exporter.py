import os
import re
import shutil

import bpy


_INVALID_FILENAME_CHARS = re.compile(r'[<>:"/\\|?*\x00-\x1f]')


def _selected_materials(context):
    return {
        slot.material
        for obj in context.selected_objects
        if obj.type == 'MESH'
        for slot in obj.material_slots
        if slot.material and slot.material.use_nodes
    }


def _collect_images_from_tree(node_tree, images, visited_trees):
    if not node_tree or node_tree.as_pointer() in visited_trees:
        return

    visited_trees.add(node_tree.as_pointer())
    for node in node_tree.nodes:
        if node.type == 'TEX_IMAGE' and node.image:
            images[node.image.as_pointer()] = node.image
        elif node.type == 'GROUP' and node.node_tree:
            _collect_images_from_tree(node.node_tree, images, visited_trees)


def _collect_images(materials):
    images = {}
    visited_trees = set()
    for material in materials:
        _collect_images_from_tree(material.node_tree, images, visited_trees)
    return list(images.values())


def _safe_filename(value):
    cleaned = _INVALID_FILENAME_CHARS.sub('_', value).strip().rstrip('.')
    return cleaned or 'texture'


def _source_path(image):
    filepath = image.filepath_raw or image.filepath
    return bpy.path.abspath(filepath) if filepath else ''


def _preferred_filename(image, source_path, force_png=False):
    candidate = os.path.basename(source_path) if source_path else image.name
    stem, extension = os.path.splitext(candidate)
    stem = _safe_filename(stem or image.name)
    if force_png or not extension:
        extension = '.png'
    return f"{stem}{extension.lower()}"


def _unique_destination(directory, filename, reserved_paths):
    stem, extension = os.path.splitext(filename)
    candidate = os.path.join(directory, filename)
    suffix = 2
    while os.path.normcase(candidate) in reserved_paths:
        candidate = os.path.join(directory, f"{stem}_{suffix}{extension}")
        suffix += 1
    reserved_paths.add(os.path.normcase(candidate))
    return candidate


def _write_packed_image(image, destination):
    packed_file = image.packed_file
    if packed_file is None:
        return False

    with open(destination, 'wb') as output:
        output.write(bytes(packed_file.data))
    return True


def _save_image_as_png(image, destination):
    old_filepath = image.filepath_raw
    old_format = image.file_format
    try:
        image.filepath_raw = destination
        image.file_format = 'PNG'
        image.save()
    finally:
        image.filepath_raw = old_filepath
        image.file_format = old_format


def _relink_image(image, destination):
    try:
        image.filepath = bpy.path.relpath(destination)
    except ValueError:
        image.filepath = destination


class BBB_OT_export_textures(bpy.types.Operator):
    bl_idname = 'bbb.export_textures'
    bl_label = '3. Export Textures for Unity'
    bl_description = (
        'Export every image used by the selected mesh materials and optionally '
        'relink the Blender images to the exported files'
    )

    def execute(self, context):
        settings = context.scene.bbb_settings
        materials = _selected_materials(context)
        if not materials:
            self.report({'ERROR'}, '请选择至少一个包含节点材质的 Mesh。')
            return {'CANCELLED'}

        if settings.texture_export_dir.startswith('//') and not bpy.data.filepath:
            self.report({'ERROR'}, '当前 .blend 尚未保存，无法解析相对输出目录。')
            return {'CANCELLED'}

        output_directory = bpy.path.abspath(settings.texture_export_dir)
        try:
            os.makedirs(output_directory, exist_ok=True)
        except OSError as error:
            self.report({'ERROR'}, f'无法创建贴图目录：{error}')
            return {'CANCELLED'}

        images = _collect_images(materials)
        if not images:
            self.report({'WARNING'}, '所选 Mesh 的材质中没有找到 Image Texture。')
            return {'CANCELLED'}

        exported = 0
        reused = 0
        skipped = []
        reserved_paths = set()

        for image in images:
            if image.source in {'TILED', 'SEQUENCE', 'MOVIE'}:
                skipped.append(f'{image.name}（暂不支持 {image.source}）')
                continue

            source_path = _source_path(image)
            has_external_source = bool(source_path and os.path.isfile(source_path))
            has_packed_source = image.packed_file is not None
            force_png = not has_external_source and not has_packed_source
            filename = _preferred_filename(image, source_path, force_png)
            destination = _unique_destination(
                output_directory, filename, reserved_paths)

            try:
                destination_exists = os.path.isfile(destination)
                same_file = False
                if has_external_source and destination_exists:
                    try:
                        same_file = os.path.samefile(source_path, destination)
                    except OSError:
                        same_file = False

                if destination_exists and not settings.overwrite_exported_textures:
                    reused += 1
                elif same_file:
                    reused += 1
                elif has_external_source:
                    shutil.copy2(source_path, destination)
                    exported += 1
                elif has_packed_source:
                    _write_packed_image(image, destination)
                    exported += 1
                elif image.has_data:
                    _save_image_as_png(image, destination)
                    exported += 1
                else:
                    skipped.append(f'{image.name}（没有可写入的图片数据）')
                    continue

                if settings.relink_exported_textures:
                    _relink_image(image, destination)
            except (OSError, RuntimeError, ValueError) as error:
                skipped.append(f'{image.name}（{error}）')

        if skipped:
            for message in skipped:
                self.report({'WARNING'}, f'跳过：{message}')

        self.report(
            {'INFO'},
            f'贴图导出完成：新增 {exported}，复用 {reused}，跳过 {len(skipped)}。'
        )
        return {'FINISHED'}


def register():
    bpy.utils.register_class(BBB_OT_export_textures)


def unregister():
    bpy.utils.unregister_class(BBB_OT_export_textures)
